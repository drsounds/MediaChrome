﻿/*
 * Created by SharpDevelop.
 * User: Alexander
 * Date: 2010-12-27
 * Time: 12:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Board
{
	/// <summary>
	/// Description of MyClass.
	/// </summary>
	public class MyClass
	{
		
	}
}