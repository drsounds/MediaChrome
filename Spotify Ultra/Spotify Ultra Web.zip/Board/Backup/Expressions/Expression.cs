using System;
using Antlr.Runtime.Tree;

namespace Jint.Expressions {
    [Serializable]
    public abstract class Expression : Statement {
    }
}
