﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jint.Marshal
{
    [AttributeUsage(AttributeTargets.Method)]
    class RawJsMethodAttribute: Attribute
    {
    }
}
