﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Jint.Native {
    public interface ILiteral {
    }
}
