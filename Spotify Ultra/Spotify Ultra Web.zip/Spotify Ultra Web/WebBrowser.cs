﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Skybound.Gecko;
namespace SpofityRuntime
{
    class WebBrowser : GeckoWebBrowser
    {
        protected override Control.ControlCollection CreateControlsInstance()
        {
        
            return base.CreateControlsInstance();
            
        }
       
        protected override void WndProc(ref Message m)
        {
            
            base.WndProc(ref m);
        }
    }
}
