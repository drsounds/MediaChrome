﻿/*
 * Created by SharpDevelop.
 * User: Alex
 * Date: 2010-11-14
 * Time: 17:44
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace SpofityRuntime
{
	/// <summary>
	/// Description of NewPlaylist.
	/// </summary>
	public partial class NewPlaylist : Form
	{
		public NewPlaylist()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
	}
}
